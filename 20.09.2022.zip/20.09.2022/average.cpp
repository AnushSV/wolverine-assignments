#include <iostream>

int main()
{
	int num1;
	int num2;
	int num3;
	int n = 3;
	int average = (num1 + num2 +num3)/n;
return 0;
}
