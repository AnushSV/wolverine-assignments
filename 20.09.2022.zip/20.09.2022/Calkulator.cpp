#include <iostream>
#include <map>
int sum_digits(int, int);
int sub_digits(int, int);
int div_digits(int, int);
int mult_digits(int, int);

int main()
{
	std::map <char, int(*)(int, int)> calc;
       	calc['+'] = & sum_digits;
	calc['-'] = & sub_digits;
	calc['/'] = & div_digits;
	calc['*'] = & mult_digits;

	int num1;
	int num2;	
	char sign;

	std::cin >> num1;
	std::cin >> num2;
	std::cin >> sign;
	
	std::cout << calc[sign](num1, num2) << std::endl;

}

int sum_digits(int num1, int num2)
{
	return num1 + num2;
}

int sub_digits(int num1, int num2)
{
	return num1 - num2;

}

int div_digits(int num1, int num2)
{
	return num1/num2;
}

int mult_digits(int num1, int num2)
{
	return num1 * num2;
}
