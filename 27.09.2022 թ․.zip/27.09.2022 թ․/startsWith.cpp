#include <iostream>
#include <string>

bool startWith(std::string, std::string);

int main()
{
	std::string s = "Hello, world";
	std::string t = "Hello";

	bool fl = startWith(s, t); 

	std::cout << fl << std::endl;

}
	bool startWith(std::string s, std::string t )
{
	bool f1 = false;
	int pos = s.find(t, 0);
	
	if(pos != std::string::npos && t[0] == s[0])
{
	f1 = true;

}

return f1;
}
