#include <iostream>
#include <string>
#include <vector>
std::vector<std::string> split(std::string, std::string);

int main()
{
	std::string s = "he,ll,o ";
	std::string d = ",";	

	std::vector<std::string> split_s = split(s,d);
	for(int i = 0; i < split_s.size(); ++i)
	{
		std::cout << split_s[i] << " " ;
	
	}
	std::cout << std::endl;


}
std::vector<std::string> split(std::string s, std::string d)
{
	int pos = 0;
	std::vector<std::string> news;
while(( pos = s.find(d)) != std::string::npos)
{
	std::string token = s.substr(0, pos);
	s.erase(0, pos + d.size());
	news.push_back(token);
}
	news.push_back(s);

	return news;
}

