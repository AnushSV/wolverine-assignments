#include <iostream>
#include <string>

std::string rtrim(std::string);

int main()
{

	std::string line = "Hello   ";

	std::string s = rtrim(line);

	std::cout << s;


}
	std::string rtrim(std::string s)
{
	
	std::string line1;
	int index = 0;
	
	for(int i = s.size()-1; s[i] == ' '; --i)
	{
			
		index = i;	
		
	}
	std::cout << index << std::endl;

	for(int i = 0; i < index; ++i)

	{
		line1 += s[i]; 
	}

	return line1;
}
