#include <iostream>
#include <string>

std::string itrim(std::string &);

int main()
{

	std::string s = "   Hello";
	std::cout << itrim(s);
}

	
std::string itrim(std::string & s)
{
	std::string line;
	int index = 0;
	
	for(int i = 0;s[i] == ' '; ++i)
	{
		
		index = i;
	
	}

	std::cout << index << std::endl;
	
	while(s[index] != '\0')
{
	line += s[++index];

}

	return line;
}
